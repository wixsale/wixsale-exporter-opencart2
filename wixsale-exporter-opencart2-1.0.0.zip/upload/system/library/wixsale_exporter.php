<?php

/**
 * WixSale catalogue export engine for OpenCart 2.x.
 *
 * PHP 5.4+ compatible. Uses url_alias for SEO URLs (OpenCart 2.x schema).
 */
class WixsaleExporter
{
	const SCHEMA = 'wixsale.opencart.catalogue';
	const SCHEMA_VERSION = 1;
	const BATCH_SIZE = 20;
	const STATE_KEY = 'wixsale_exporter_state';

	private $registry;
	private $db;
	private $config;
	private $request;
	private $default_language_id = 0;
	private $language_cache = array();

	public function __construct($registry)
	{
		$this->registry = $registry;
		$this->db = $registry->get('db');
		$this->config = $registry->get('config');
		$this->request = $registry->get('request');
		$this->default_language_id = (int)$this->config->get('config_language_id');
		$this->loadLanguages();
	}

	public function getState()
	{
		$raw = $this->config->get(self::STATE_KEY);

		if (is_array($raw)) {
			return $raw;
		}

		if (is_string($raw) && $raw !== '') {
			$decoded = json_decode($raw, true);

			return is_array($decoded) ? $decoded : array();
		}

		return array();
	}

	public function setState($state)
	{
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'wixsale_exporter' AND `key` = '" . $this->db->escape(self::STATE_KEY) . "'");
		$this->db->query("INSERT INTO `" . DB_PREFIX . "setting` SET `store_id` = '0', `code` = 'wixsale_exporter', `key` = '" . $this->db->escape(self::STATE_KEY) . "', `value` = '" . $this->db->escape(json_encode($state)) . "', `serialized` = '1'");
		$this->config->set(self::STATE_KEY, $state);
	}

	public function clearState()
	{
		$state = $this->getState();
		$this->deleteStateFiles($state);
		$this->db->query("DELETE FROM `" . DB_PREFIX . "setting` WHERE `code` = 'wixsale_exporter' AND `key` = '" . $this->db->escape(self::STATE_KEY) . "'");
	}

	public function sanitizeFilters($filters)
	{
		$status = isset($filters['status']) ? $filters['status'] : 'enabled';

		if (!in_array($status, array('enabled', 'all', 'disabled'), true)) {
			$status = 'enabled';
		}

		$stock = isset($filters['stock']) ? $filters['stock'] : 'all';

		if (!in_array($stock, array('all', 'instock', 'outofstock'), true)) {
			$stock = 'all';
		}

		$page_size = isset($filters['page_size']) ? (int)$filters['page_size'] : 0;

		if (!in_array($page_size, array(0, 100, 300, 500, 1000), true)) {
			$page_size = 0;
		}

		return array(
			'category' => isset($filters['category']) ? (int)$filters['category'] : 0,
			'status' => $status,
			'stock' => $stock,
			'page_size' => $page_size,
		);
	}

	public function countProducts($filters)
	{
		$sql = $this->productBaseSql($filters);
		$query = $this->db->query("SELECT COUNT(DISTINCT p.product_id) AS total " . $sql['from'] . $sql['where']);

		return (int)$query->row['total'];
	}

	public function startExport($filters)
	{
		$filters = $this->sanitizeFilters($filters);
		$this->clearState();

		$total = $this->countProducts($filters);
		$page_size = $filters['page_size'] > 0 ? $filters['page_size'] : max(1, $total);
		$page_count = max(1, (int)ceil(($total > 0 ? $total : 1) / $page_size));

		$token = $this->generateToken();
		$dir = $this->exportRoot() . $token . '/';

		if (!$this->ensureDirectory($dir)) {
			throw new Exception('The export directory could not be created.');
		}

		$this->protectDirectory($this->exportRoot());
		$this->protectDirectory($dir);

		$tmp_path = $dir . 'catalogue-page-1.tmp';
		$state = array(
			'status' => 'running',
			'token' => $token,
			'dir' => $dir,
			'tmp_path' => $tmp_path,
			'paths' => array(),
			'offset' => 0,
			'processed' => 0,
			'total' => $total,
			'page' => 1,
			'page_size' => $page_size,
			'page_count' => $page_count,
			'page_processed' => 0,
			'filters' => $filters,
			'first' => true,
			'started_at' => gmdate('c'),
		);

		$this->openFeed($state);
		$this->setState($state);

		return $this->progressPayload($state);
	}

	public function stepExport()
	{
		$state = $this->getState();

		if (empty($state['status']) || $state['status'] !== 'running' || empty($state['tmp_path'])) {
			throw new Exception('No active export was found.');
		}

		$remaining = min(self::BATCH_SIZE, $state['page_size'] - $state['page_processed']);
		$product_ids = $this->fetchProductIds((int)$state['offset'], $remaining, $state['filters']);

		$handle = fopen($state['tmp_path'], 'ab');

		if ($handle === false) {
			throw new Exception('The export file is no longer writable.');
		}

		foreach ($product_ids as $product_id) {
			$product = $this->serializeProduct((int)$product_id);
			$json = json_encode($product, JSON_UNESCAPED_UNICODE);

			if ($json === false) {
				fclose($handle);
				throw new Exception('Product ' . (int)$product_id . ' could not be encoded as JSON.');
			}

			fwrite($handle, ($state['first'] ? '' : ',') . $json);
			$state['first'] = false;
			$state['processed']++;
			$state['page_processed']++;
		}

		fclose($handle);
		$state['offset'] += count($product_ids);

		$page_complete = $state['page_processed'] >= $state['page_size'] || $state['processed'] >= $state['total'] || empty($product_ids);

		if ($page_complete) {
			file_put_contents($state['tmp_path'], "]}\n", FILE_APPEND | LOCK_EX);
			$path = $state['dir'] . 'wixsale-products-page-' . $state['page'] . '-of-' . $state['page_count'] . '.json';

			if (!rename($state['tmp_path'], $path)) {
				throw new Exception('The final export file could not be created.');
			}

			$state['paths'][] = $path;
		}

		if ($state['processed'] >= $state['total'] || ($state['total'] === 0 && $page_complete) || (empty($product_ids) && $page_complete)) {
			$state['status'] = 'complete';
			$state['finished_at'] = gmdate('c');
			unset($state['tmp_path'], $state['first']);
		} elseif ($page_complete) {
			$state['page']++;
			$state['page_processed'] = 0;
			$state['first'] = true;
			$state['tmp_path'] = $state['dir'] . 'catalogue-page-' . $state['page'] . '.tmp';
			$this->openFeed($state);
		}

		$this->setState($state);

		return $this->progressPayload($state);
	}

	public function progressPayload($state)
	{
		$total = max(0, (int)$state['total']);
		$percent = $total ? min(100, round(((int)$state['processed'] / $total) * 100, 1)) : 100;
		$downloads = array();

		if (!empty($state['status']) && $state['status'] === 'complete' && !empty($state['paths'])) {
			foreach ($state['paths'] as $index => $path) {
				$downloads[] = array(
					'index' => $index,
					'label' => sprintf('Download feed %1$d of %2$d', $index + 1, count($state['paths'])),
					'path' => $path,
				);
			}
		}

		return array(
			'status' => isset($state['status']) ? $state['status'] : 'idle',
			'processed' => isset($state['processed']) ? (int)$state['processed'] : 0,
			'total' => $total,
			'percent' => $percent,
			'page' => isset($state['page']) ? (int)$state['page'] : 1,
			'pageCount' => isset($state['page_count']) ? (int)$state['page_count'] : 1,
			'downloads' => $downloads,
		);
	}

	public function getDownloadPath($index)
	{
		$state = $this->getState();

		if (empty($state['status']) || $state['status'] !== 'complete' || empty($state['paths'][$index])) {
			return '';
		}

		$path = $state['paths'][$index];

		return is_readable($path) ? $path : '';
	}

	private function openFeed($state)
	{
		$handle = fopen($state['tmp_path'], 'wb');

		if ($handle === false) {
			throw new Exception('The export file could not be opened for writing.');
		}

		$header = $this->exportHeader($state);
		$encoded = json_encode($header, JSON_UNESCAPED_UNICODE);

		if ($encoded === false) {
			fclose($handle);
			throw new Exception('The export header could not be encoded as JSON.');
		}

		$encoded = substr($encoded, 1, -1);
		fwrite($handle, '{' . $encoded . ',"products":[');
		fclose($handle);
	}

	private function exportHeader($state)
	{
		return array(
			'schema' => self::SCHEMA,
			'schema_version' => self::SCHEMA_VERSION,
			'generated_at' => gmdate('c'),
			'pagination' => array(
				'page' => isset($state['page']) ? (int)$state['page'] : 1,
				'pages' => isset($state['page_count']) ? (int)$state['page_count'] : 1,
				'per_page' => isset($state['page_size']) ? (int)$state['page_size'] : null,
				'total_products' => isset($state['total']) ? (int)$state['total'] : null,
			),
			'filters' => isset($state['filters']) ? $state['filters'] : array(),
			'site' => $this->siteMeta(),
			'languages' => $this->siteLanguages(),
			'categories' => $this->serializeCategories(),
			'manufacturers' => $this->serializeManufacturers(),
			'attributes' => $this->serializeGlobalAttributes(),
			'options' => $this->serializeGlobalOptions(),
		);
	}

	private function siteMeta()
	{
		$store_url = $this->config->get('config_url');
		$store_ssl = $this->config->get('config_ssl');

		if (!empty($this->request->server['HTTPS']) && $store_ssl) {
			$store_url = $store_ssl;
		}

		return array(
			'url' => $store_url,
			'name' => $this->config->get('config_name'),
			'opencart_version' => defined('VERSION') ? VERSION : null,
			'currency' => $this->config->get('config_currency'),
			'weight_class_id' => (int)$this->config->get('config_weight_class_id'),
			'length_class_id' => (int)$this->config->get('config_length_class_id'),
			'weight_unit' => $this->weightUnit(),
			'dimension_unit' => $this->lengthUnit(),
		);
	}

	private function siteLanguages()
	{
		$active = array();

		foreach ($this->language_cache as $language) {
			$active[] = $language['code'];
		}

		$default = isset($this->language_cache[$this->default_language_id]) ? $this->language_cache[$this->default_language_id]['code'] : '';

		return array(
			'default' => $default,
			'active' => $active,
			'provider' => 'opencart',
			'languages' => array_values($this->language_cache),
		);
	}

	private function serializeCategories()
	{
		$query = $this->db->query("SELECT c.* FROM `" . DB_PREFIX . "category` c ORDER BY c.sort_order, c.category_id");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = $this->serializeCategoryRow($row);
		}

		return $items;
	}

	private function serializeCategoryRow($row)
	{
		$category_id = (int)$row['category_id'];
		$descriptions = $this->categoryDescriptions($category_id);
		$default = isset($descriptions[$this->default_language_id]) ? $descriptions[$this->default_language_id] : reset($descriptions);

		return array(
			'id' => $category_id,
			'parent_id' => (int)$row['parent_id'],
			'name' => $default ? $default['name'] : '',
			'description' => $default ? $default['description'] : '',
			'meta_title' => $default ? (isset($default['meta_title']) ? $default['meta_title'] : '') : '',
			'meta_description' => $default ? (isset($default['meta_description']) ? $default['meta_description'] : '') : '',
			'meta_keyword' => $default ? (isset($default['meta_keyword']) ? $default['meta_keyword'] : '') : '',
			'path' => $this->categoryPath($category_id, $this->default_language_id),
			'image' => $this->imagePayload($row['image']),
			'sort_order' => (int)$row['sort_order'],
			'status' => (int)$row['status'],
			'seo_urls' => $this->categorySeoUrls($category_id),
			'descriptions' => $descriptions,
		);
	}

	private function serializeManufacturers()
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "manufacturer` ORDER BY name");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'id' => (int)$row['manufacturer_id'],
				'name' => $row['name'],
				'image' => $this->imagePayload($row['image']),
				'sort_order' => isset($row['sort_order']) ? (int)$row['sort_order'] : 0,
				'seo_urls' => $this->manufacturerSeoUrls((int)$row['manufacturer_id']),
			);
		}

		return $items;
	}

	private function serializeGlobalAttributes()
	{
		$query = $this->db->query("SELECT a.attribute_id, a.attribute_group_id, ad.language_id, ad.name FROM `" . DB_PREFIX . "attribute` a LEFT JOIN `" . DB_PREFIX . "attribute_description` ad ON a.attribute_id = ad.attribute_id ORDER BY a.sort_order, a.attribute_id");
		$items = array();

		foreach ($query->rows as $row) {
			$id = (int)$row['attribute_id'];

			if (!isset($items[$id])) {
				$items[$id] = array(
					'id' => $id,
					'attribute_group_id' => (int)$row['attribute_group_id'],
					'names' => array(),
				);
			}

			if ($row['language_id']) {
				$items[$id]['names'][(int)$row['language_id']] = $row['name'];
			}
		}

		return array_values($items);
	}

	private function serializeGlobalOptions()
	{
		$query = $this->db->query("SELECT o.option_id, o.type, o.sort_order, od.language_id, od.name FROM `" . DB_PREFIX . "option` o LEFT JOIN `" . DB_PREFIX . "option_description` od ON o.option_id = od.option_id ORDER BY o.sort_order, o.option_id");
		$items = array();

		foreach ($query->rows as $row) {
			$id = (int)$row['option_id'];

			if (!isset($items[$id])) {
				$items[$id] = array(
					'id' => $id,
					'type' => $row['type'],
					'sort_order' => (int)$row['sort_order'],
					'names' => array(),
					'values' => $this->optionValues($id),
				);
			}

			if ($row['language_id']) {
				$items[$id]['names'][(int)$row['language_id']] = $row['name'];
			}
		}

		return array_values($items);
	}

	private function optionValues($option_id)
	{
		$query = $this->db->query("SELECT ov.option_value_id, ov.image, ov.sort_order, ovd.language_id, ovd.name FROM `" . DB_PREFIX . "option_value` ov LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON ov.option_value_id = ovd.option_value_id WHERE ov.option_id = '" . (int)$option_id . "' ORDER BY ov.sort_order, ov.option_value_id");
		$items = array();

		foreach ($query->rows as $row) {
			$id = (int)$row['option_value_id'];

			if (!isset($items[$id])) {
				$items[$id] = array(
					'id' => $id,
					'image' => $this->imagePayload($row['image']),
					'sort_order' => (int)$row['sort_order'],
					'names' => array(),
				);
			}

			if ($row['language_id']) {
				$items[$id]['names'][(int)$row['language_id']] = $row['name'];
			}
		}

		return array_values($items);
	}

	public function serializeProduct($product_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product` WHERE product_id = '" . (int)$product_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return array('id' => (int)$product_id);
		}

		$row = $query->row;
		$descriptions = $this->productDescriptions($product_id);
		$default = isset($descriptions[$this->default_language_id]) ? $descriptions[$this->default_language_id] : reset($descriptions);
		$images = $this->productImages($product_id, $row['image']);
		$categories = $this->productCategories($product_id);
		$attributes = $this->productAttributes($product_id);
		$options = $this->productOptions($product_id);
		$specials = $this->productSpecials($product_id);
		$discounts = $this->productDiscounts($product_id);
		$related = $this->productRelated($product_id);
		$downloads = $this->productDownloads($product_id);
		$stores = $this->productStores($product_id);
		$filters = $this->productFilters($product_id);
		$manufacturer = $this->manufacturerById((int)$row['manufacturer_id']);
		$seo_urls = $this->productSeoUrls($product_id);
		$language_code = $this->languageCode($this->default_language_id);

		$data = array(
			'id' => (int)$product_id,
			'type' => $this->productType($options),
			'name' => $default ? $default['name'] : '',
			'description' => $default ? $default['description'] : '',
			'tag' => $default ? (isset($default['tag']) ? $default['tag'] : '') : '',
			'meta_title' => $default ? (isset($default['meta_title']) ? $default['meta_title'] : '') : '',
			'meta_description' => $default ? (isset($default['meta_description']) ? $default['meta_description'] : '') : '',
			'meta_keyword' => $default ? (isset($default['meta_keyword']) ? $default['meta_keyword'] : '') : '',
			'model' => $row['model'],
			'sku' => $row['sku'],
			'upc' => $row['upc'],
			'ean' => $row['ean'],
			'jan' => $row['jan'],
			'isbn' => $row['isbn'],
			'mpn' => $row['mpn'],
			'location' => $row['location'],
			'quantity' => (int)$row['quantity'],
			'minimum' => (int)$row['minimum'],
			'subtract' => (int)$row['subtract'],
			'stock_status_id' => (int)$row['stock_status_id'],
			'stock_status' => $this->stockStatusLabel((int)$row['stock_status_id']),
			'date_available' => $row['date_available'],
			'manufacturer_id' => (int)$row['manufacturer_id'],
			'manufacturer' => $manufacturer,
			'shipping' => (int)$row['shipping'],
			'price' => $row['price'],
			'points' => (int)$row['points'],
			'tax_class_id' => (int)$row['tax_class_id'],
			'date_added' => $row['date_added'],
			'date_modified' => $row['date_modified'],
			'weight' => $row['weight'],
			'weight_class_id' => (int)$row['weight_class_id'],
			'length' => $row['length'],
			'width' => $row['width'],
			'height' => $row['height'],
			'length_class_id' => (int)$row['length_class_id'],
			'status' => (int)$row['status'],
			'sort_order' => (int)$row['sort_order'],
			'prices' => array(
				'price' => $row['price'],
				'specials' => $specials,
				'discounts' => $discounts,
				'sale_price' => $this->currentSpecialPrice($specials),
			),
			'stock' => array(
				'quantity' => (int)$row['quantity'],
				'subtract' => (int)$row['subtract'],
				'stock_status_id' => (int)$row['stock_status_id'],
				'stock_status' => $this->stockStatusLabel((int)$row['stock_status_id']),
				'minimum' => (int)$row['minimum'],
			),
			'shipping_data' => array(
				'weight' => $row['weight'],
				'weight_class_id' => (int)$row['weight_class_id'],
				'length' => $row['length'],
				'width' => $row['width'],
				'height' => $row['height'],
				'length_class_id' => (int)$row['length_class_id'],
				'shipping' => (int)$row['shipping'],
			),
			'images' => $images,
			'categories' => $categories,
			'attributes' => $attributes,
			'options' => $options,
			'related_product_ids' => $related,
			'downloads' => $downloads,
			'stores' => $stores,
			'filters' => $filters,
			'seo_urls' => $seo_urls,
			'descriptions' => $descriptions,
		);

		return $this->addCompatibilityFields($data, $language_code, $images, $categories, $manufacturer, $specials, $row);
	}

	private function addCompatibilityFields($data, $language_code, $images, $categories, $manufacturer, $specials, $row)
	{
		$image_urls = array();

		foreach ($images as $image) {
			if (!empty($image['url'])) {
				$image_urls[] = $image['url'];
			}
		}

		$category_paths = array();

		foreach ($categories as $category) {
			if (!empty($category['path'])) {
				$category_paths[] = str_replace(' > ', '>', $category['path']);
			}
		}

		$featured = array_shift($image_urls);
		$sale_price = $this->currentSpecialPrice($specials);

		$aliases = array(
			'barcode' => $row['ean'] ? $row['ean'] : ($row['upc'] ? $row['upc'] : null),
			'warehouse_location' => $row['location'],
			'price' => $row['price'],
			'sale_price' => $sale_price,
			'track_inventory' => (int)$row['subtract'],
			'brand' => $manufacturer ? $manufacturer['name'] : '',
			'featured_image' => $featured ? $featured : '',
			'images_feed' => implode('|', $image_urls),
			'active' => (int)$row['status'],
			'categories_feed' => implode('|', array_unique($category_paths)),
			'seo_url' => $this->primarySeoKeyword(isset($data['seo_urls']) ? $data['seo_urls'] : array(), $this->default_language_id),
		);

		$aliases['name_' . $language_code] = $data['name'];
		$aliases['description_' . $language_code] = $data['description'];
		$aliases['meta_title_' . $language_code] = $data['meta_title'];
		$aliases['meta_description_' . $language_code] = $data['meta_description'];
		$aliases['meta_keywords_' . $language_code] = $data['meta_keyword'];
		$aliases['seo_url_' . $language_code] = $aliases['seo_url'];
		$aliases['categories_' . $language_code] = $aliases['categories_feed'];

		foreach ($data['descriptions'] as $language_id => $description) {
			$code = $this->languageCode($language_id);

			if ($code === '') {
				continue;
			}

			$aliases['name_' . $code] = $description['name'];
			$aliases['description_' . $code] = $description['description'];
			$aliases['meta_title_' . $code] = isset($description['meta_title']) ? $description['meta_title'] : '';
			$aliases['meta_description_' . $code] = isset($description['meta_description']) ? $description['meta_description'] : '';
			$aliases['meta_keywords_' . $code] = isset($description['meta_keyword']) ? $description['meta_keyword'] : '';
			$aliases['seo_url_' . $code] = $this->primarySeoKeyword($data['seo_urls'], $language_id);
			$aliases['categories_' . $code] = $aliases['categories_feed'];
		}

		return array_merge($data, $aliases);
	}

	private function productType($options)
	{
		foreach ($options as $option) {
			if (!empty($option['values']) && in_array($option['type'], array('select', 'radio', 'image', 'checkbox'), true)) {
				return 'variable';
			}
		}

		return 'simple';
	}

	private function productDescriptions($product_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_description` WHERE product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[(int)$row['language_id']] = array(
				'language_id' => (int)$row['language_id'],
				'language_code' => $this->languageCode((int)$row['language_id']),
				'name' => $row['name'],
				'description' => $row['description'],
				'tag' => isset($row['tag']) ? $row['tag'] : '',
				'meta_title' => isset($row['meta_title']) ? $row['meta_title'] : '',
				'meta_description' => isset($row['meta_description']) ? $row['meta_description'] : '',
				'meta_keyword' => isset($row['meta_keyword']) ? $row['meta_keyword'] : '',
			);
		}

		return $items;
	}

	private function productImages($product_id, $main_image)
	{
		$items = array();
		$index = 0;

		if ($main_image) {
			$items[] = array_merge($this->imagePayload($main_image), array('featured' => true, 'sort_order' => $index++));
		}

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_image` WHERE product_id = '" . (int)$product_id . "' ORDER BY sort_order, product_image_id");

		foreach ($query->rows as $row) {
			$items[] = array_merge($this->imagePayload($row['image']), array('featured' => false, 'sort_order' => (int)$row['sort_order'] + $index));
		}

		return $items;
	}

	private function productCategories($product_id)
	{
		$query = $this->db->query("SELECT p2c.category_id, c.parent_id FROM `" . DB_PREFIX . "product_to_category` p2c LEFT JOIN `" . DB_PREFIX . "category` c ON p2c.category_id = c.category_id WHERE p2c.product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$category_id = (int)$row['category_id'];
			$descriptions = $this->categoryDescriptions($category_id);
			$default = isset($descriptions[$this->default_language_id]) ? $descriptions[$this->default_language_id] : reset($descriptions);

			$items[] = array(
				'id' => $category_id,
				'parent_id' => (int)$row['parent_id'],
				'name' => $default ? $default['name'] : '',
				'path' => $this->categoryPath($category_id, $this->default_language_id),
			);
		}

		return $items;
	}

	private function productAttributes($product_id)
	{
		$query = $this->db->query("SELECT pa.attribute_id, pa.language_id, pa.text, ad.name AS attribute_name, agd.name AS group_name FROM `" . DB_PREFIX . "product_attribute` pa LEFT JOIN `" . DB_PREFIX . "attribute_description` ad ON pa.attribute_id = ad.attribute_id AND pa.language_id = ad.language_id LEFT JOIN `" . DB_PREFIX . "attribute` a ON pa.attribute_id = a.attribute_id LEFT JOIN `" . DB_PREFIX . "attribute_group_description` agd ON a.attribute_group_id = agd.attribute_group_id AND pa.language_id = agd.language_id WHERE pa.product_id = '" . (int)$product_id . "' ORDER BY a.sort_order, pa.attribute_id");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'attribute_id' => (int)$row['attribute_id'],
				'language_id' => (int)$row['language_id'],
				'language_code' => $this->languageCode((int)$row['language_id']),
				'name' => $row['attribute_name'],
				'group_name' => $row['group_name'],
				'text' => $row['text'],
			);
		}

		return $items;
	}

	private function productOptions($product_id)
	{
		$query = $this->db->query("SELECT po.*, o.type, od.name AS option_name FROM `" . DB_PREFIX . "product_option` po LEFT JOIN `" . DB_PREFIX . "option` o ON po.option_id = o.option_id LEFT JOIN `" . DB_PREFIX . "option_description` od ON po.option_id = od.option_id AND od.language_id = '" . (int)$this->default_language_id . "' WHERE po.product_id = '" . (int)$product_id . "' ORDER BY po.product_option_id");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'product_option_id' => (int)$row['product_option_id'],
				'option_id' => (int)$row['option_id'],
				'name' => $row['option_name'],
				'type' => $row['type'],
				'required' => (int)$row['required'],
				'value' => $row['value'],
				'values' => $this->productOptionValues((int)$row['product_option_id']),
			);
		}

		return $items;
	}

	private function productOptionValues($product_option_id)
	{
		$query = $this->db->query("SELECT pov.*, ovd.name AS value_name FROM `" . DB_PREFIX . "product_option_value` pov LEFT JOIN `" . DB_PREFIX . "option_value_description` ovd ON pov.option_value_id = ovd.option_value_id AND ovd.language_id = '" . (int)$this->default_language_id . "' WHERE pov.product_option_id = '" . (int)$product_option_id . "' ORDER BY pov.product_option_value_id");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'product_option_value_id' => (int)$row['product_option_value_id'],
				'option_value_id' => (int)$row['option_value_id'],
				'name' => $row['value_name'],
				'quantity' => (int)$row['quantity'],
				'subtract' => (int)$row['subtract'],
				'price' => $row['price'],
				'price_prefix' => $row['price_prefix'],
				'points' => (int)$row['points'],
				'points_prefix' => $row['points_prefix'],
				'weight' => $row['weight'],
				'weight_prefix' => $row['weight_prefix'],
			);
		}

		return $items;
	}

	private function productSpecials($product_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_special` WHERE product_id = '" . (int)$product_id . "' ORDER BY priority, price");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'customer_group_id' => (int)$row['customer_group_id'],
				'priority' => (int)$row['priority'],
				'price' => $row['price'],
				'date_start' => $row['date_start'],
				'date_end' => $row['date_end'],
			);
		}

		return $items;
	}

	private function productDiscounts($product_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "product_discount` WHERE product_id = '" . (int)$product_id . "' ORDER BY quantity, priority, price");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'customer_group_id' => (int)$row['customer_group_id'],
				'quantity' => (int)$row['quantity'],
				'priority' => (int)$row['priority'],
				'price' => $row['price'],
				'date_start' => $row['date_start'],
				'date_end' => $row['date_end'],
			);
		}

		return $items;
	}

	private function productRelated($product_id)
	{
		$query = $this->db->query("SELECT related_id FROM `" . DB_PREFIX . "product_related` WHERE product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = (int)$row['related_id'];
		}

		return $items;
	}

	private function productDownloads($product_id)
	{
		$query = $this->db->query("SELECT d.download_id, d.filename, d.mask, dd.name FROM `" . DB_PREFIX . "product_to_download` p2d LEFT JOIN `" . DB_PREFIX . "download` d ON p2d.download_id = d.download_id LEFT JOIN `" . DB_PREFIX . "download_description` dd ON d.download_id = dd.download_id AND dd.language_id = '" . (int)$this->default_language_id . "' WHERE p2d.product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'id' => (int)$row['download_id'],
				'name' => $row['name'],
				'filename' => $row['filename'],
				'mask' => $row['mask'],
			);
		}

		return $items;
	}

	private function productStores($product_id)
	{
		$query = $this->db->query("SELECT store_id FROM `" . DB_PREFIX . "product_to_store` WHERE product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = (int)$row['store_id'];
		}

		return $items;
	}

	private function productFilters($product_id)
	{
		if (!$this->tableExists('product_filter')) {
			return array();
		}

		$query = $this->db->query("SELECT pf.filter_id, fd.name, f.filter_group_id, fgd.name AS group_name FROM `" . DB_PREFIX . "product_filter` pf LEFT JOIN `" . DB_PREFIX . "filter_description` fd ON pf.filter_id = fd.filter_id AND fd.language_id = '" . (int)$this->default_language_id . "' LEFT JOIN `" . DB_PREFIX . "filter` f ON pf.filter_id = f.filter_id LEFT JOIN `" . DB_PREFIX . "filter_group_description` fgd ON f.filter_group_id = fgd.filter_group_id AND fgd.language_id = '" . (int)$this->default_language_id . "' WHERE pf.product_id = '" . (int)$product_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = array(
				'filter_id' => (int)$row['filter_id'],
				'name' => $row['name'],
				'group_id' => (int)$row['filter_group_id'],
				'group_name' => $row['group_name'],
			);
		}

		return $items;
	}

	private function manufacturerById($manufacturer_id)
	{
		if ($manufacturer_id < 1) {
			return null;
		}

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "manufacturer` WHERE manufacturer_id = '" . (int)$manufacturer_id . "' LIMIT 1");

		if (!$query->num_rows) {
			return null;
		}

		return array(
			'id' => (int)$query->row['manufacturer_id'],
			'name' => $query->row['name'],
			'image' => $this->imagePayload($query->row['image']),
		);
	}

	private function categoryDescriptions($category_id)
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_description` WHERE category_id = '" . (int)$category_id . "'");
		$items = array();

		foreach ($query->rows as $row) {
			$items[(int)$row['language_id']] = array(
				'language_id' => (int)$row['language_id'],
				'language_code' => $this->languageCode((int)$row['language_id']),
				'name' => $row['name'],
				'description' => $row['description'],
				'meta_title' => isset($row['meta_title']) ? $row['meta_title'] : '',
				'meta_description' => isset($row['meta_description']) ? $row['meta_description'] : '',
				'meta_keyword' => isset($row['meta_keyword']) ? $row['meta_keyword'] : '',
			);
		}

		return $items;
	}

	private function categoryPath($category_id, $language_id)
	{
		if (!$this->tableExists('category_path')) {
			return '';
		}

		$query = $this->db->query("SELECT cp.path_id, cd.name FROM `" . DB_PREFIX . "category_path` cp LEFT JOIN `" . DB_PREFIX . "category_description` cd ON cp.path_id = cd.category_id AND cd.language_id = '" . (int)$language_id . "' WHERE cp.category_id = '" . (int)$category_id . "' ORDER BY cp.level");
		$parts = array();

		foreach ($query->rows as $row) {
			if ($row['name'] !== '') {
				$parts[] = $row['name'];
			}
		}

		return implode(' > ', $parts);
	}

	private function productSeoUrls($product_id)
	{
		return $this->lookupSeoUrls('product_id=' . (int)$product_id);
	}

	private function categorySeoUrls($category_id)
	{
		return $this->lookupSeoUrls('category_id=' . (int)$category_id);
	}

	private function manufacturerSeoUrls($manufacturer_id)
	{
		return $this->lookupSeoUrls('manufacturer_id=' . (int)$manufacturer_id);
	}

	private function lookupSeoUrls($query_value)
	{
		if ($this->tableExists('seo_url')) {
			$query = $this->db->query("SELECT store_id, language_id, keyword FROM `" . DB_PREFIX . "seo_url` WHERE `query` = '" . $this->db->escape($query_value) . "'");
			$items = array();

			foreach ($query->rows as $row) {
				$items[] = array(
					'store_id' => (int)$row['store_id'],
					'language_id' => (int)$row['language_id'],
					'language_code' => $this->languageCode((int)$row['language_id']),
					'keyword' => $row['keyword'],
				);
			}

			return $items;
		}

		$query = $this->db->query("SELECT keyword FROM `" . DB_PREFIX . "url_alias` WHERE `query` = '" . $this->db->escape($query_value) . "' LIMIT 1");

		if (!$query->num_rows) {
			return array();
		}

		return array(
			array(
				'store_id' => 0,
				'language_id' => $this->default_language_id,
				'language_code' => $this->languageCode($this->default_language_id),
				'keyword' => $query->row['keyword'],
			),
		);
	}

	private function primarySeoKeyword($seo_urls, $language_id)
	{
		foreach ($seo_urls as $seo) {
			if ((int)$seo['language_id'] === (int)$language_id && !empty($seo['keyword'])) {
				return $seo['keyword'];
			}
		}

		if (!empty($seo_urls[0]['keyword'])) {
			return $seo_urls[0]['keyword'];
		}

		return '';
	}

	private function currentSpecialPrice($specials)
	{
		$today = date('Y-m-d');

		foreach ($specials as $special) {
			$start = ($special['date_start'] === '0000-00-00' || $special['date_start'] === '') ? null : $special['date_start'];
			$end = ($special['date_end'] === '0000-00-00' || $special['date_end'] === '') ? null : $special['date_end'];

			if ($start && $start > $today) {
				continue;
			}

			if ($end && $end < $today) {
				continue;
			}

			return $special['price'];
		}

		return null;
	}

	private function stockStatusLabel($stock_status_id)
	{
		$query = $this->db->query("SELECT name FROM `" . DB_PREFIX . "stock_status` WHERE stock_status_id = '" . (int)$stock_status_id . "' AND language_id = '" . (int)$this->default_language_id . "' LIMIT 1");

		return $query->num_rows ? $query->row['name'] : '';
	}

	private function imagePayload($path)
	{
		if (!$path) {
			return array('path' => '', 'url' => '');
		}

		return array(
			'path' => $path,
			'url' => $this->imageUrl($path),
		);
	}

	private function imageUrl($path)
	{
		if (!$path) {
			return '';
		}

		if (strpos($path, 'http://') === 0 || strpos($path, 'https://') === 0) {
			return $path;
		}

		$base = $this->config->get('config_url');

		if (!empty($this->request->server['HTTPS']) && $this->config->get('config_ssl')) {
			$base = $this->config->get('config_ssl');
		}

		if (defined('HTTPS_CATALOG') && HTTPS_CATALOG) {
			$base = HTTPS_CATALOG;
		} elseif (defined('HTTP_CATALOG') && HTTP_CATALOG) {
			$base = HTTP_CATALOG;
		}

		return rtrim($base, '/') . '/image/' . str_replace(' ', '%20', ltrim($path, '/'));
	}

	private function weightUnit()
	{
		$query = $this->db->query("SELECT unit FROM `" . DB_PREFIX . "weight_class_description` WHERE weight_class_id = '" . (int)$this->config->get('config_weight_class_id') . "' AND language_id = '" . (int)$this->default_language_id . "' LIMIT 1");

		return $query->num_rows ? $query->row['unit'] : '';
	}

	private function lengthUnit()
	{
		$query = $this->db->query("SELECT unit FROM `" . DB_PREFIX . "length_class_description` WHERE length_class_id = '" . (int)$this->config->get('config_length_class_id') . "' AND language_id = '" . (int)$this->default_language_id . "' LIMIT 1");

		return $query->num_rows ? $query->row['unit'] : '';
	}

	private function fetchProductIds($offset, $limit, $filters)
	{
		$sql = $this->productBaseSql($filters);
		$query = $this->db->query("SELECT DISTINCT p.product_id " . $sql['from'] . $sql['where'] . " ORDER BY p.product_id ASC LIMIT " . (int)$offset . "," . (int)$limit);
		$items = array();

		foreach ($query->rows as $row) {
			$items[] = (int)$row['product_id'];
		}

		return $items;
	}

	private function productBaseSql($filters)
	{
		$filters = $this->sanitizeFilters($filters);
		$from = "FROM `" . DB_PREFIX . "product` p";
		$joins = array();
		$where = array('1=1');

		if ($filters['category'] > 0) {
			$joins[] = "INNER JOIN `" . DB_PREFIX . "product_to_category` p2c ON p.product_id = p2c.product_id";

			if ($this->tableExists('category_path')) {
				$joins[] = "INNER JOIN `" . DB_PREFIX . "category_path` cp ON p2c.category_id = cp.category_id";
				$where[] = "cp.path_id = '" . (int)$filters['category'] . "'";
			} else {
				$where[] = "p2c.category_id = '" . (int)$filters['category'] . "'";
			}
		}

		if ($filters['status'] === 'enabled') {
			$where[] = "p.status = '1'";
		} elseif ($filters['status'] === 'disabled') {
			$where[] = "p.status = '0'";
		}

		if ($filters['stock'] === 'instock') {
			$where[] = "(p.quantity > 0 OR p.subtract = '0')";
		} elseif ($filters['stock'] === 'outofstock') {
			$where[] = "(p.quantity <= 0 AND p.subtract = '1')";
		}

		return array(
			'from' => $from . ' ' . implode(' ', $joins),
			'where' => ' WHERE ' . implode(' AND ', $where),
		);
	}

	private function loadLanguages()
	{
		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "language` WHERE status = '1' ORDER BY sort_order, name");

		foreach ($query->rows as $row) {
			$this->language_cache[(int)$row['language_id']] = array(
				'language_id' => (int)$row['language_id'],
				'name' => $row['name'],
				'code' => $row['code'],
				'locale' => isset($row['locale']) ? $row['locale'] : $row['code'],
				'image' => isset($row['image']) ? $row['image'] : '',
				'directory' => $row['directory'],
				'sort_order' => (int)$row['sort_order'],
				'status' => (int)$row['status'],
			);
		}
	}

	private function languageCode($language_id)
	{
		if (isset($this->language_cache[$language_id])) {
			return $this->languageCodeFromLocale($this->language_cache[$language_id]['code']);
		}

		return '';
	}

	private function languageCodeFromLocale($code)
	{
		$code = strtolower(str_replace('_', '-', $code));

		if (strpos($code, '-') !== false) {
			return substr($code, 0, strpos($code, '-'));
		}

		return $code;
	}

	private function exportRoot()
	{
		if (defined('DIR_STORAGE')) {
			return rtrim(DIR_STORAGE, '/') . '/wixsale-exports/';
		}

		if (defined('DIR_DOWNLOAD')) {
			return rtrim(DIR_DOWNLOAD, '/') . '/wixsale-exports/';
		}

		return rtrim(DIR_SYSTEM, '/') . '/storage/wixsale-exports/';
	}

	private function ensureDirectory($dir)
	{
		if (is_dir($dir)) {
			return true;
		}

		return mkdir($dir, 0755, true);
	}

	private function protectDirectory($dir)
	{
		$this->ensureDirectory($dir);
		$index = rtrim($dir, '/') . '/index.html';

		if (!file_exists($index)) {
			file_put_contents($index, '<!DOCTYPE html><html><head><title>403 Forbidden</title></head><body><p>Directory access is forbidden.</p></body></html>');
		}

		$htaccess = rtrim($dir, '/') . '/.htaccess';

		if (!file_exists($htaccess)) {
			file_put_contents($htaccess, "Require all denied\nDeny from all\n");
		}
	}

	private function deleteStateFiles($state)
	{
		if (!empty($state['tmp_path']) && is_file($state['tmp_path'])) {
			@unlink($state['tmp_path']);
		}

		if (!empty($state['paths']) && is_array($state['paths'])) {
			foreach ($state['paths'] as $path) {
				if (is_file($path)) {
					@unlink($path);
				}
			}
		}
	}

	private function generateToken()
	{
		if (function_exists('openssl_random_pseudo_bytes')) {
			return bin2hex(openssl_random_pseudo_bytes(16));
		}

		return md5(uniqid((string)mt_rand(), true));
	}

	private function tableExists($table)
	{
		$query = $this->db->query("SHOW TABLES LIKE '" . $this->db->escape(DB_PREFIX . $table) . "'");

		return (bool)$query->num_rows;
	}
}
