<?php

$_['heading_title'] = 'WixSale Exporter';
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified WixSale Exporter!';
$_['text_edit'] = 'WixSale Exporter';
$_['text_home'] = 'Home';
$_['text_enabled'] = 'Enabled';
$_['text_disabled'] = 'Disabled';
$_['text_included'] = 'Included';
$_['text_included_help'] = 'Products, options/variants, stock, prices, categories, manufacturers, attributes, images, downloads, dimensions, weights, SEO URLs, multi-language descriptions and filter tags.';
$_['text_storage'] = 'Storage';
$_['text_storage_help'] = 'Files are stored in a protected random directory under system/storage and can only be downloaded by an administrator.';
$_['text_filters'] = 'Export filters';
$_['text_all_categories'] = 'All categories / all products';
$_['text_category_help'] = 'Child categories are included.';
$_['text_status_enabled'] = 'Enabled products';
$_['text_status_all'] = 'All statuses';
$_['text_status_disabled'] = 'Disabled products';
$_['text_stock_all'] = 'All stock statuses';
$_['text_stock_in'] = 'In stock';
$_['text_stock_out'] = 'Out of stock';
$_['text_page_single'] = 'One feed (no split)';
$_['text_page_help'] = 'Large catalogues can be split into numbered JSON feeds.';
$_['text_generate'] = 'Generate JSON export';
$_['text_cancel'] = 'Cancel';
$_['text_download_feed'] = 'Download feed %d of %d';
$_['text_last_export'] = 'Last export';
$_['text_generated_files'] = 'Generated files';
$_['text_calculating'] = 'Calculating product count…';
$_['text_products'] = 'products selected';
$_['text_working'] = 'Exporting… Do not close this page.';
$_['text_failed'] = 'The export stopped because of an error.';
$_['text_complete'] = 'Export complete.';

$_['entry_status'] = 'Status';
$_['entry_category'] = 'Category';
$_['entry_product_status'] = 'Product status';
$_['entry_stock'] = 'Stock status';
$_['entry_page_size'] = 'Products per feed';

$_['button_save'] = 'Save';
$_['button_cancel'] = 'Cancel';

$_['error_permission'] = 'Warning: You do not have permission to modify WixSale Exporter!';
$_['error_unknown_action'] = 'Unknown export action.';
$_['error_download'] = 'Export file not found.';
