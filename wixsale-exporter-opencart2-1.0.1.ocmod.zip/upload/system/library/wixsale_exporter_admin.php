<?php

/**
 * Shared admin actions for WixSale Exporter on OpenCart 2.x.
 */
class WixsaleExporterAdmin
{
	public static function sessionTokenKey()
	{
		return isset($GLOBALS['registry']) ? self::detectTokenKey($GLOBALS['registry']) : 'token';
	}

	public static function detectTokenKey($registry)
	{
		$session = $registry->get('session');

		if (isset($session->data['user_token'])) {
			return 'user_token';
		}

		return 'token';
	}

	public static function routePrefix()
	{
		if (defined('VERSION') && version_compare(VERSION, '2.3.0.0', '>=')) {
			return 'extension/module/wixsale_exporter';
		}

		return 'module/wixsale_exporter';
	}

	public static function permissionRoute()
	{
		return self::routePrefix();
	}

	public static function sslFlag()
	{
		return 'SSL';
	}

	public static function renderPage($controller)
	{
		if ($controller->user->isLogged()) {
			self::grantPermissions($controller, $controller->user->getGroupId());
		}

		$controller->load->language(self::routePrefix());
		$controller->document->setTitle($controller->language->get('heading_title'));
		$controller->load->model('setting/setting');
		$controller->load->library('wixsale_exporter');
		$exporter = new WixsaleExporter($controller->registry);

		$token_key = self::detectTokenKey($controller->registry);
		$token = $controller->session->data[$token_key];
		$route = self::routePrefix();
		$ssl = self::sslFlag();

		$data = array();
		$data['heading_title'] = $controller->language->get('heading_title');
		$data['text_edit'] = $controller->language->get('text_edit');
		$data['button_cancel'] = $controller->language->get('button_cancel');
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $controller->language->get('text_home'),
			'href' => $controller->url->link('common/dashboard', $token_key . '=' . $token, $ssl),
		);
		$data['breadcrumbs'][] = array(
			'text' => $controller->language->get('text_extension'),
			'href' => $controller->url->link('extension/extension', $token_key . '=' . $token . '&type=module', $ssl),
		);
		$data['breadcrumbs'][] = array(
			'text' => $controller->language->get('heading_title'),
			'href' => $controller->url->link($route, $token_key . '=' . $token, $ssl),
		);

		$data['cancel'] = $controller->url->link('extension/extension', $token_key . '=' . $token . '&type=module', $ssl);
		$data['error_warning'] = '';

		$controller->load->model('catalog/category');
		$data['categories'] = $controller->model_catalog_category->getCategories(array());

		$state = $exporter->getState();
		$data['export_complete'] = !empty($state['status']) && $state['status'] === 'complete';
		$data['export_finished_at'] = !empty($state['finished_at']) ? $state['finished_at'] : '';
		$data['export_file_count'] = !empty($state['paths']) ? count($state['paths']) : 0;
		$data['download_links'] = array();

		if ($data['export_complete'] && !empty($state['paths'])) {
			foreach ($state['paths'] as $index => $path) {
				if (is_readable($path)) {
					$data['download_links'][] = array(
						'label' => sprintf($controller->language->get('text_download_feed'), $index + 1, count($state['paths'])),
						'href' => self::buildDownloadUrl($controller, $route, $token_key, $token, (int)$index, $ssl),
					);
				}
			}
		}

		$data['token_key'] = $token_key;
		$data['token'] = $token;
		$data['ajax_url'] = self::buildAjaxUrl($controller, $route, $token_key, $token, $ssl);

		$lang_keys = array(
			'text_included', 'text_included_help', 'text_storage', 'text_storage_help', 'text_filters',
			'entry_category', 'text_all_categories', 'text_category_help', 'entry_product_status',
			'text_status_enabled', 'text_status_all', 'text_status_disabled', 'entry_stock',
			'text_stock_all', 'text_stock_in', 'text_stock_out', 'entry_page_size', 'text_page_single',
			'text_page_help', 'text_calculating', 'text_generate', 'text_cancel', 'text_last_export',
			'text_generated_files', 'text_working', 'text_failed', 'text_complete', 'text_products',
		);

		foreach ($lang_keys as $key) {
			$data[$key] = $controller->language->get($key);
		}

		$data['header'] = $controller->load->controller('common/header');
		$data['column_left'] = $controller->load->controller('common/column_left');
		$data['footer'] = $controller->load->controller('common/footer');

		$controller->response->setOutput($controller->load->view('module/wixsale_exporter.tpl', $data));
	}

	public static function handleAjax($controller)
	{
		$controller->load->language(self::routePrefix());
		$json = array();
		$permission = self::permissionRoute();

		if (!$controller->user->hasPermission('modify', $permission)) {
			$json['error'] = $controller->language->get('error_permission');
		} else {
			$controller->load->library('wixsale_exporter');
			$exporter = new WixsaleExporter($controller->registry);
			$action = isset($controller->request->post['wixsale_action']) ? $controller->request->post['wixsale_action'] : '';

			try {
				switch ($action) {
					case 'count':
						$json['total'] = $exporter->countProducts(self::requestFilters($controller));
						break;
					case 'start':
						$json = $exporter->startExport(self::requestFilters($controller));
						break;
					case 'step':
						$json = $exporter->stepExport();
						break;
					case 'cancel':
						$exporter->clearState();
						$json['success'] = true;
						break;
					default:
						$json['error'] = $controller->language->get('error_unknown_action');
				}
			} catch (Exception $e) {
				$json['error'] = $e->getMessage();
			}

			if (!isset($json['error']) && in_array($action, array('start', 'step'), true) && isset($json['status']) && $json['status'] === 'complete') {
				$token_key = self::detectTokenKey($controller->registry);
				$token = $controller->session->data[$token_key];
				$route = self::routePrefix();
				$payload = $exporter->progressPayload($exporter->getState());
				$json['downloads'] = array();

				foreach ($payload['downloads'] as $item) {
					$json['downloads'][] = array(
						'label' => $item['label'],
						'url' => self::buildDownloadUrl($controller, $route, $token_key, $token, (int)$item['index'], self::sslFlag()),
					);
				}
			}
		}

		$controller->response->addHeader('Content-Type: application/json');
		$controller->response->setOutput(json_encode($json));
	}

	public static function handleDownload($controller)
	{
		$controller->load->language(self::routePrefix());
		$token_key = self::detectTokenKey($controller->registry);
		$token = $controller->session->data[$token_key];
		$route = self::routePrefix();

		if (!$controller->user->hasPermission('modify', self::permissionRoute())) {
			$controller->response->redirect($controller->url->link('error/permission', $token_key . '=' . $token, self::sslFlag()));
			return;
		}

		$controller->load->library('wixsale_exporter');
		$exporter = new WixsaleExporter($controller->registry);
		$index = isset($controller->request->get['page']) ? (int)$controller->request->get['page'] : 0;
		$path = $exporter->getDownloadPath($index);

		if (!$path) {
			$controller->session->data['error'] = $controller->language->get('error_download');
			$controller->response->redirect($controller->url->link($route, $token_key . '=' . $token, self::sslFlag()));
			return;
		}

		if (!headers_sent()) {
			header('Content-Type: application/json; charset=utf-8');
			header('Content-Disposition: attachment; filename="' . basename($path) . '"');
			header('Content-Length: ' . filesize($path));
			header('Cache-Control: no-store, no-cache, must-revalidate');
			header('Pragma: no-cache');
		}

		readfile($path);
		exit;
	}

	public static function requestFilters($controller)
	{
		return array(
			'category' => isset($controller->request->post['category']) ? (int)$controller->request->post['category'] : 0,
			'status' => isset($controller->request->post['status']) ? $controller->request->post['status'] : 'enabled',
			'stock' => isset($controller->request->post['stock']) ? $controller->request->post['stock'] : 'all',
			'page_size' => isset($controller->request->post['page_size']) ? (int)$controller->request->post['page_size'] : 0,
		);
	}

	public static function buildAjaxUrl($controller, $route, $token_key, $token, $ssl)
	{
		return self::decodeUrl($controller->url->link($route . '/ajax', $token_key . '=' . $token, $ssl));
	}

	public static function buildDownloadUrl($controller, $route, $token_key, $token, $page, $ssl)
	{
		return self::decodeUrl($controller->url->link($route . '/download', $token_key . '=' . $token . '&page=' . (int)$page, $ssl));
	}

	public static function decodeUrl($url)
	{
		return html_entity_decode($url, ENT_QUOTES, 'UTF-8');
	}

	public static function grantPermissions($controller, $group_id)
	{
		$controller->load->model('user/user_group');

		$routes = array(
			self::permissionRoute(),
			self::permissionRoute() . '/ajax',
			self::permissionRoute() . '/download',
		);

		foreach ($routes as $route) {
			$controller->model_user_user_group->addPermission((int)$group_id, 'access', $route);
			$controller->model_user_user_group->addPermission((int)$group_id, 'modify', $route);
		}
	}
}
