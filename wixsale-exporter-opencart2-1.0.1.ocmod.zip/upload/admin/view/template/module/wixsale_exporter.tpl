<?php echo $header; ?><?php echo $column_left; ?>
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a>
      </div>
      <h1><?php echo $heading_title; ?></h1>
      <ul class="breadcrumb">
        <?php foreach ($breadcrumbs as $breadcrumb) { ?>
        <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
        <?php } ?>
      </ul>
    </div>
  </div>
  <div class="container-fluid">
    <?php if ($error_warning) { ?>
    <div class="alert alert-danger alert-dismissible"><i class="fa fa-exclamation-circle"></i> <?php echo $error_warning; ?>
      <button type="button" class="close" data-dismiss="alert">&times;</button>
    </div>
    <?php } ?>
    <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> <?php echo $text_edit; ?></h3>
      </div>
      <div class="panel-body">
        <table class="table table-bordered" style="max-width:900px">
          <tbody>
            <tr><th style="width:220px"><?php echo $text_included; ?></th><td><?php echo $text_included_help; ?></td></tr>
            <tr><th><?php echo $text_storage; ?></th><td><?php echo $text_storage_help; ?></td></tr>
            <?php if ($export_complete) { ?>
            <tr><th><?php echo $text_last_export; ?></th><td><?php echo $export_finished_at; ?></td></tr>
            <tr><th><?php echo $text_generated_files; ?></th><td><?php echo $export_file_count; ?></td></tr>
            <?php } ?>
          </tbody>
        </table>

        <h3><?php echo $text_filters; ?></h3>
        <div class="form-horizontal" style="max-width:900px">
          <div class="form-group">
            <label class="col-sm-3 control-label" for="wixsale-category"><?php echo $entry_category; ?></label>
            <div class="col-sm-9">
              <select id="wixsale-category" class="form-control">
                <option value="0"><?php echo $text_all_categories; ?></option>
                <?php foreach ($categories as $category) { ?>
                <option value="<?php echo $category['category_id']; ?>"><?php echo $category['name']; ?></option>
                <?php } ?>
              </select>
              <p class="help-block"><?php echo $text_category_help; ?></p>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label" for="wixsale-status"><?php echo $entry_product_status; ?></label>
            <div class="col-sm-9">
              <select id="wixsale-status" class="form-control">
                <option value="enabled"><?php echo $text_status_enabled; ?></option>
                <option value="all"><?php echo $text_status_all; ?></option>
                <option value="disabled"><?php echo $text_status_disabled; ?></option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label" for="wixsale-stock"><?php echo $entry_stock; ?></label>
            <div class="col-sm-9">
              <select id="wixsale-stock" class="form-control">
                <option value="all"><?php echo $text_stock_all; ?></option>
                <option value="instock"><?php echo $text_stock_in; ?></option>
                <option value="outofstock"><?php echo $text_stock_out; ?></option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="col-sm-3 control-label" for="wixsale-page-size"><?php echo $entry_page_size; ?></label>
            <div class="col-sm-9">
              <select id="wixsale-page-size" class="form-control">
                <option value="0" selected><?php echo $text_page_single; ?></option>
                <option value="100">100</option>
                <option value="300">300</option>
                <option value="500">500</option>
                <option value="1000">1000</option>
              </select>
              <p class="help-block"><?php echo $text_page_help; ?></p>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-offset-3 col-sm-9"><strong id="wixsale-product-count"><?php echo $text_calculating; ?></strong></div>
          </div>
        </div>

        <p>
          <button type="button" class="btn btn-primary" id="wixsale-export-start"><?php echo $text_generate; ?></button>
          <button type="button" class="btn btn-default" id="wixsale-export-cancel" style="display:none"><?php echo $text_cancel; ?></button>
        </p>

        <div id="wixsale-export-downloads" style="margin-bottom:15px">
          <?php foreach ($download_links as $link) { ?>
          <a class="btn btn-default wixsale-download" style="margin:0 8px 8px 0" href="<?php echo $link['href']; ?>"><?php echo $link['label']; ?></a>
          <?php } ?>
        </div>

        <div id="wixsale-export-progress" style="display:none;max-width:700px">
          <div class="progress">
            <div class="progress-bar" role="progressbar" style="width:0%"></div>
          </div>
          <p class="message"></p>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript"><!--
(function ($) {
  'use strict';
  var running = false, countTimer;
  var ajaxUrl = '<?php echo addslashes($ajax_url); ?>'.replace(/&amp;/g, '&');
  var i18n = {
    working: '<?php echo addslashes($text_working); ?>',
    failed: '<?php echo addslashes($text_failed); ?>',
    products: '<?php echo addslashes($text_products); ?>',
    complete: '<?php echo addslashes($text_complete); ?>'
  };

  function filters() {
    return {
      category: $('#wixsale-category').val(),
      status: $('#wixsale-status').val(),
      stock: $('#wixsale-stock').val(),
      page_size: $('#wixsale-page-size').val()
    };
  }

  function request(action, data) {
    var payload = $.extend({}, filters(), data || {}, { wixsale_action: action });
    return $.ajax({
      url: ajaxUrl,
      type: 'POST',
      dataType: 'json',
      cache: false,
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      data: payload
    });
  }

  function showError(xhr) {
    var message = i18n.failed;
    if (xhr && xhr.responseJSON && xhr.responseJSON.error) {
      message += ' ' + xhr.responseJSON.error;
    }
    $('#wixsale-export-progress .message').text(message).css('color', '#a94442');
    $('#wixsale-export-start').prop('disabled', false);
    $('#wixsale-export-cancel').hide();
    running = false;
  }

  function refreshCount() {
    clearTimeout(countTimer);
    $('#wixsale-product-count').text('<?php echo addslashes($text_calculating); ?>');
    countTimer = setTimeout(function () {
      request('count').done(function (response) {
        if (response.total !== undefined) {
          $('#wixsale-product-count').text(response.total + ' ' + i18n.products);
        }
      }).fail(function () {
        $('#wixsale-product-count').text('Product count unavailable');
      });
    }, 180);
  }

  function update(data) {
    $('#wixsale-export-progress .progress-bar').css('width', data.percent + '%');
    $('#wixsale-export-progress .message').text(i18n.working + ' ' + data.processed + ' / ' + data.total + ' (' + data.percent + '%), feed ' + data.page + ' / ' + data.pageCount).css('color', '');
    if (data.status === 'complete') {
      running = false;
      $('#wixsale-export-start').prop('disabled', false);
      $('#wixsale-export-cancel').hide();
      $('#wixsale-export-progress .message').text(i18n.complete + ' ' + data.processed + ' products in ' + data.downloads.length + ' feed(s).');
      $('#wixsale-export-downloads').empty();
      $.each(data.downloads, function (_, item) {
        var downloadUrl = String(item.url || '').replace(/&amp;/g, '&');
        $('<a class="btn btn-default wixsale-download" style="margin:0 8px 8px 0"></a>').text(item.label).attr('href', downloadUrl).appendTo('#wixsale-export-downloads');
      });
      return;
    }
    request('step').done(function (response) {
      if (response.error) { showError({ responseJSON: response }); return; }
      update(response);
    }).fail(showError);
  }

  $(function () {
    $('#wixsale-category,#wixsale-status,#wixsale-stock,#wixsale-page-size').on('change', refreshCount);
    refreshCount();
    $('#wixsale-export-start').on('click', function () {
      if (running) { return; }
      running = true;
      $('#wixsale-export-start').prop('disabled', true);
      $('#wixsale-export-cancel').show();
      $('#wixsale-export-progress').show();
      $('#wixsale-export-progress .progress-bar').css('width', '0');
      $('#wixsale-export-downloads').empty();
      $('#wixsale-export-progress .message').text(i18n.working).css('color', '');
      request('start').done(function (response) {
        if (response.error) { showError({ responseJSON: response }); return; }
        update(response);
      }).fail(showError);
    });
    $('#wixsale-export-cancel').on('click', function () {
      running = false;
      request('cancel').always(function () { window.location.reload(); });
    });
  });
}(jQuery));
//--></script>
<?php echo $footer; ?>
