<?php

require_once DIR_SYSTEM . 'library/wixsale_exporter_admin.php';

class ControllerModuleWixsaleExporter extends Controller
{
	public function index()
	{
		WixsaleExporterAdmin::renderPage($this);
	}

	public function install()
	{
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('wixsale_exporter', array('wixsale_exporter_status' => 1));
		WixsaleExporterAdmin::grantPermissions($this, $this->user->getGroupId());
	}

	public function uninstall()
	{
		$this->load->library('wixsale_exporter');
		$exporter = new WixsaleExporter($this->registry);
		$exporter->clearState();
	}

	public function ajax()
	{
		WixsaleExporterAdmin::handleAjax($this);
	}

	public function download()
	{
		WixsaleExporterAdmin::handleDownload($this);
	}
}
